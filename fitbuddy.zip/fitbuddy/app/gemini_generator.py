"""Workout plan generation with Gemini Pro."""
from app.config import generate, GEMINI_PRO_MODEL

DISCLAIMER = "\n\nNote: Consult a doctor before starting any new workout routine."


def generate_workout_gemini(user_input: dict) -> str:
    prompt = f"""
You are a professional fitness trainer.

Create a personalized, structured 7-day workout plan for someone with the goal of
**{user_input['goal']}**, who prefers **{user_input['intensity']}** intensity workouts.

Each day must include:
- A warm-up (5-10 mins)
- Main workout (targeted exercises, sets & reps)
- Cooldown or recovery tip

Format:
Day 1:
Warm-up: ...
Main Workout: ...
Cooldown: ...
(Repeat for Day 2-7)
"""
    try:
        return generate(GEMINI_PRO_MODEL, prompt) + DISCLAIMER
    except Exception as e:
        return f"Error: {e}"
