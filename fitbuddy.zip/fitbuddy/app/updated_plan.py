"""Feedback-based plan updates with Gemini Pro."""
from app.config import generate, GEMINI_PRO_MODEL


def update_workout_plan(original_plan: str, user_feedback: str) -> str:
    prompt = f"""
You are a professional fitness trainer assistant.

Here's the original 7-day workout plan:
{original_plan}

User Feedback:
"{user_feedback}"

Based on the feedback, revise the relevant parts of the workout plan.
Keep the format and the rest of the plan unchanged if not needed.
"""
    try:
        return generate(GEMINI_PRO_MODEL, prompt)
    except Exception as e:
        return f"Error updating plan: {e}"
