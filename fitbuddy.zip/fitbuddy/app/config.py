"""Central config: API key and model names (change models in .env)."""
import os
from dotenv import load_dotenv
from google import genai

load_dotenv()

GEMINI_PRO_MODEL = os.getenv("GEMINI_PRO_MODEL", "gemini-2.5-pro")
GEMINI_FLASH_MODEL = os.getenv("GEMINI_FLASH_MODEL", "gemini-2.5-flash")

_api_key = os.getenv("GOOGLE_API_KEY")
client = genai.Client(api_key=_api_key) if _api_key else None


def generate(model: str, prompt: str) -> str:
    if client is None:
        raise RuntimeError("GOOGLE_API_KEY is not set in the .env file")
    response = client.models.generate_content(model=model, contents=prompt)
    return (response.text or "").strip()
