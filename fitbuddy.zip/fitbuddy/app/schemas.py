"""Pydantic models for request validation."""
from pydantic import BaseModel


class UserInput(BaseModel):
    user_id: int
    username: str
    age: int
    weight: float
    goal: str
    intensity: str  # low | medium | high


class FeedbackRequest(BaseModel):
    feedback: str


class WorkoutRequest(BaseModel):
    goal: str
    intensity: str
