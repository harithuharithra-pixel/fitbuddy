"""Nutrition / recovery tips with Gemini Flash."""
from app.config import generate, GEMINI_FLASH_MODEL


def generate_nutrition_tip_with_flash(goal: str) -> str:
    """Return one nutrition or recovery tip for the user's fitness goal."""
    prompt = (
        f"Give one clear, helpful nutrition or recovery tip for someone focused on '{goal}'. "
        "The tip should be practical, friendly, and easy to understand."
    )
    try:
        return generate(GEMINI_FLASH_MODEL, prompt)
    except Exception as e:
        return f"Error generating tip: {e}"
