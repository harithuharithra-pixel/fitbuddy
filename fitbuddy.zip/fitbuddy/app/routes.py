"""All route handlers: web pages + JSON API."""
import os
from fastapi import APIRouter, Request, Form, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates

from app.schemas import UserInput, FeedbackRequest, WorkoutRequest
from app.database import (save_user, save_plan, update_plan, get_original_plan,
                          get_user, get_all_users, get_all_plans)
from app.gemini_generator import generate_workout_gemini
from app.gemini_flash_generator import generate_nutrition_tip_with_flash
from app.updated_plan import update_workout_plan

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
templates = Jinja2Templates(directory=os.path.join(BASE_DIR, "templates"))
router = APIRouter()


# ---------------- Web pages ----------------
@router.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse(request, "index.html", {})


@router.post("/generate-workout", response_class=HTMLResponse)
def generate_workout(request: Request,
                     username: str = Form(...), user_id: int = Form(...),
                     age: int = Form(...), weight: float = Form(...),
                     goal: str = Form(...), intensity: str = Form(...)):
    data = UserInput(user_id=user_id, username=username, age=age,
                     weight=weight, goal=goal, intensity=intensity)
    plan = generate_workout_gemini({"goal": data.goal, "intensity": data.intensity})
    tip = generate_nutrition_tip_with_flash(data.goal)
    save_user(data.user_id, data.username, data.age, data.weight, data.goal, data.intensity)
    save_plan(data.user_id, plan)
    return templates.TemplateResponse(request, "result.html", {
        "username": data.username, "user_id": data.user_id, "age": data.age,
        "weight": data.weight, "goal": data.goal, "intensity": data.intensity,
        "workout_plan": plan, "nutrition_tip": tip, "message": None,
    })


@router.post("/submit-feedback", response_class=HTMLResponse)
def submit_feedback(request: Request, user_id: int = Form(...), feedback: str = Form(...)):
    original = get_original_plan(user_id)
    user = get_user(user_id)
    if not original or not user:
        return templates.TemplateResponse(request, "result.html", {
            "username": "", "user_id": user_id, "age": "", "weight": "", "goal": "",
            "intensity": "", "workout_plan": "Original plan not found for this user.",
            "nutrition_tip": "", "message": None,
        })
    updated = update_workout_plan(original, feedback)
    update_plan(user_id, updated)
    tip = generate_nutrition_tip_with_flash(user.goal)
    return templates.TemplateResponse(request, "result.html", {
        "username": user.name, "user_id": user.id, "age": user.age,
        "weight": user.weight, "goal": user.goal, "intensity": user.intensity,
        "workout_plan": updated, "nutrition_tip": tip,
        "message": "✅ Your plan has been updated based on your feedback!",
    })


@router.get("/view-all-users", response_class=HTMLResponse)
def view_all_users(request: Request):
    plans = {p.user_id: p for p in get_all_plans()}
    user_data = []
    for u in get_all_users():
        p = plans.get(u.id)
        user_data.append({
            "id": u.id, "name": u.name, "age": u.age, "weight": u.weight,
            "goal": u.goal, "intensity": u.intensity,
            "original_plan": p.original_plan if p else "N/A",
            "updated_plan": p.updated_plan if p and p.updated_plan else "Not updated",
        })
    return templates.TemplateResponse(request, "all_users.html", {"users": user_data})


# ---------------- JSON API ----------------
@router.post("/generate-workout/gemini")
def api_generate_workout(req: WorkoutRequest):
    try:
        result = generate_workout_gemini({"goal": req.goal, "intensity": req.intensity})
        return {"model": "gemini-pro", "workout_plan": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/nutrition-tip")
def api_nutrition_tip(goal: str):
    return {"goal": goal, "nutrition_tip": generate_nutrition_tip_with_flash(goal)}


@router.post("/generate-plan")
def api_generate_plan(user_data: UserInput):
    try:
        save_user(user_data.user_id, user_data.username, user_data.age,
                  user_data.weight, user_data.goal, user_data.intensity)
        plan = generate_workout_gemini({"goal": user_data.goal, "intensity": user_data.intensity})
        save_plan(user_data.user_id, plan)
        return {"message": "Workout plan generated and saved successfully!", "workout_plan": plan}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Something went wrong: {e}")


@router.post("/update-plan/{user_id}")
def api_update_plan(user_id: int, data: FeedbackRequest):
    original = get_original_plan(user_id)
    if not original:
        raise HTTPException(status_code=404, detail="Original plan not found for this user.")
    updated = update_workout_plan(original, data.feedback)
    update_plan(user_id, updated)
    return {"updated_plan": updated}
